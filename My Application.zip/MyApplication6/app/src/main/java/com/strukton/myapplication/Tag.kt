package com.strukton.myapplication

data class Tag(
    val id: Int,
    val name: String
)
