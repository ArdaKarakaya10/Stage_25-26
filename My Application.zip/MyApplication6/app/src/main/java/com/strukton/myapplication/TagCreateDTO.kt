package com.strukton.myapplication

data class TagCreateDto(
    val name: String
)